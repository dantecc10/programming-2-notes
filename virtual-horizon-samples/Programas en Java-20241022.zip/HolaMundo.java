public class HolaMundo {
	public static void main(String[] args) {
		System.out.println("Hola Mundo!!\n");
		System.out.println("Otra linea");
	}
}
